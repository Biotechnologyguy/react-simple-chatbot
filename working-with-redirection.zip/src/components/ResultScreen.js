import React from "react";
import { AgGridReact } from "ag-grid-react";
import "../ag-grid/ag-grid.css";
import "../ag-grid/ag-theme-alpine.css";


const ResultScreen = ({ matchedTrades, matchedStatements }) => {
  

  const tradeColumnDefs = [
    { headerName: "Trade ID", field: "tradeid" },
    { headerName: "Trader Name", field: "tradername" },
    { headerName: "Settlement ID", field: "settlementid" },
    { headerName: "Amount", field: "amount" },
    { headerName: "Counterparty", field: "counterparty" },
    { headerName: "Currency", field: "currency" },
  ];

  const statementColumnDefs = [
    { headerName: "Entry ID", field: "entryid" },
    { headerName: "Reference 1", field: "reference1" },
    { headerName: "Reference 2", field: "reference2" },
    { headerName: "Reference 3", field: "reference3" },
    { headerName: "Amount", field: "amount" },
    { headerName: "Currency", field: "currency" },
  ];

  return (
    <div style={{ display: "flex", height: "100%" }}>
      <div style={{ flex: 1 }}>
        <h2>Matched Trades:</h2>
        <div
          className="ag-theme-alpine"
          style={{ height: "50vh", width: "100%" }}
        >
          <AgGridReact
            rowData={matchedTrades}
            columnDefs={tradeColumnDefs}
            pagination={true}
          ></AgGridReact>
        </div>
      </div>
      <div style={{ flex: 1 }}>
        <h2>Matched Statements:</h2>
        <div
          className="ag-theme-alpine"
          style={{ height: "50vh", width: "100%" }}
        >
          <AgGridReact
            rowData={matchedStatements}
            columnDefs={statementColumnDefs}
            pagination={true}
            debug={true}
          ></AgGridReact>
        </div>
      </div>
    </div>
  );
};

export default ResultScreen;
